import java.util.*;
import org.javatuples.*;

public class MidtermIDSOC {
    public static void main(String [] args){

        Scanner in = new Scanner(System.in);
        Set<String>setNames = new HashSet<>();
        Map<String, String>genID = new HashMap<>();
        ArrayList<String>names = new ArrayList<>();
        ArrayList<String>id = new ArrayList<>();  
        System.out.println("This is a Java application that generates ID of a name.");
        while (true) { 
            System.out.print("Enter a name: ");
            names.add(in.nextLine());
            setNames.addAll(names);
            if(setNames.size() == 5){
                break;
            }
        }
        names.clear();
        names.addAll(setNames);
        names.sort(Comparator.naturalOrder());
        Quintet <String, String, String, String, String> tupNames = Quintet.fromCollection(names);
        System.out.println("The names inputted: " + tupNames);
        id.addAll(generateID(names));
        for(int index = 0; index < names.size(); index++){
            genID.put(names.get(index), id.get(index));
        }
        System.out.println("List of names with generated IDs:");
        for(String mel: genID.keySet()){
            System.out.println("Name: " + mel + "\tID: " + genID.get(mel));
        }
        //in.close();
        
    }
    public static ArrayList<String> generateID(ArrayList<String> n){
        ArrayList <String> id = new ArrayList<>();
        int index = 0;
        for(String namae: n){
            int no = namae.length();
            id.add(("SOC-" + no + index));
            index++;
        }
        return id;
    }
}