/*
 * Create a Java application that allows the user to input eight fruit names and save them in a 4x2 size String array. Replace all the "a" and "A" characters in the names with "#," and print all the names with total characters exceeding 6.
 */
import java.util.*;
public class Midterm2Fruits {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int count = 0;
        String names[][] = new String[4][2];
        System.out.println("This Java application allows the user to input 8 fruit names, and print the names exceeding 6 characters. ");
        for(int r = 0; r < 4; r++){
            for(int c = 0; c < 2; c++){
                System.out.print("Enter a fruit name: ");
                String temp = in.nextLine();
                names[r][c] = temp.replace("a", "#");
                names[r][c] = names[r][c].replace("A", "#");
                //names[r][c] = names[r][c].replaceAll("[A, a]", "#");
                if(names[r][c].length() > 6)
                    count++;
            }
        }
        if(count != 0){
            System.out.println("The names exceeding 6 characters: ");        
            for(int r = 0; r < 4; r++){
                for(int c = 0; c < 2; c++){
                    if(names[r][c].length() > 6)
                    System.out.print(names[r][c] + " ");
                }
            }
        }else{
            System.out.println("No name exceeds 6 characters.");
        }
        in.close();
    }
}