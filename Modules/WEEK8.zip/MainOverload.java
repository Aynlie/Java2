public class MainOverload {
    public static void main(String[] args) {
        print();
        System.out.println("The square root of 9: " + Math.sqrt(9));
    }
    //method overloading
    public static void print(){
        System.out.println("Hello World!");
    }

    public static void print(String n){
        System.out.println("Hello! " + n);
    }
    public static String print(String x, int s){
        return "PROGSDATS";
    } 

}
