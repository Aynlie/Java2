import java.util.*;
public class Main {
    public static void main(String[] args) {
        try{
            Scanner in = new Scanner(System.in);
            int num1 = 0;
            int num2 = 0;
            int quotient = 0;
            System.out.print("Enter a numerator: ");
            num1 = in.nextInt();
            System.out.print("Enter a denominator: ");
            num2 = in.nextInt();
            quotient = num1 / num2;
            System.out.println("The quotient is : " + quotient);
        }catch(InputMismatchException error){
            System.out.println("Error: " + error.getMessage());
        }
        catch(Exception e){
            System.out.println("An exception occurs.");
        }
        finally{
            System.out.println("Good bye!");
        }
    }
    
}
