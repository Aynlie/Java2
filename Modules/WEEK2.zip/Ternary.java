public class Ternary{
	public static void main(String [] args){
		int x = 10;
		String mes = x < 10? "Yes" : "No";

		/*if(x < 10){
			mes = "Yes";
		}else{
			mes = "No";
		}*/

		System.out.println(mes); 
	}
}