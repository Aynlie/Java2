public class LoopSample{
	public static void main(String [] args){
		/*for(int x = 100; x >= 10; x-=10){
			System.out.println("SOC");
			if(x == 60){
				break;
			}
		}*/
		//int i = 1;
		/*for(;;){
			System.out.println("SOC");
			if(i == 5){
				break;
			}
			i+=1;
		}*/
		/*int i = 1;
		while(i >= -3){
			System.out.println("SOC");
			i--;
		}
		*/
		int a = 5;
		do{
			System.out.println("SOC");
			a+=5;
		}while(a <= 25);
	}
}