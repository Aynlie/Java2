//Create an application that will print the value of the variable res 5 times.
import java.text.DecimalFormat;
public class Looping{
	public static void main(String [] args){
		DecimalFormat df = new DecimalFormat("#.##");
		double res = 10.975;
		//System.out.println(res);
		//System.out.println(df.format(res));
		
		//initialization; condition; counter (dec/inc)
		/*for(int i = 1; i <= 5; i++){
			System.out.println("Hello ");
			if(i > 2){
				continue;	//skip
			}
			System.out.println("World!");

		}*/
		//indefinite loop
		/*int i = 1;
		for(;;){
			System.out.println("Hello World!");
			if(i == 5){
				break; //terminate loop
			}
			i++;
		}*/

		/*
		//augmented operation
		//x = x + 1
		//x+=1 (x = x + 1)

		//x++ (x = x + 1) postfix
		//++x (x = 1 + x) prefix
		
		int x = 10;
		x*=2; // x = x * 2;
		x-=1;   //x = x - 1; //x--; --x;
		x%=3; //x = x % 3; 1
		//System.out.println("Initial: " + x++); //delay
		//System.out.println("Initial: " + ++x); 
		//System.out.println("Initial: " + (x+=1));
		System.out.println("Second: " + x);

	*/


		/*int i = 1; //initialization
		while(i <= 5){ //condition
			System.out.println("Hello World!");
			++i; //counter
		}*/

		int i = 3;
		do{
			System.out.println("Hello World!");
			i+=5; //18
		}while(i <= 15);

	}
}


//continue
//break