import java.util.HashMap;
import java.util.Map;

public class SampleMap {
    public static void main(String[] args) {
        Map <Integer, String> hm = new HashMap<Integer, String>();
        //adding
        hm.put(101, "6PROGSDATS");
        hm.put(102, "PURCOMM");
        hm.put(103, "6PHCI");

        System.out.println(hm.get(103));
        //changing
        hm.put(103, "6DSMATH");
        System.out.println(hm.get(103));
        //remove
        hm.remove(101);
        System.out.println(hm.get(101));

        //traverse
        System.out.println("Updated map: ");
        for(Integer k: hm.keySet()){
            System.out.println("Key: " + k + " - Value: " + hm.get(k));
        }
    }

}
