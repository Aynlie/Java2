import org.javatuples.*;

import java.util.*;
public class App {
    public static void main(String[] args) throws Exception {
        //Pair <Integer, String> tup = Pair.with(1, "java");
        Pair <Integer, String> tup = new Pair <> (2, "Hello");
        Pair <Integer, String> newTup;
        Unit <Integer> one;
        Quartet <String, Double, Integer, String> qt;
        //set
        newTup = tup.setAt0(6);

        //remove
        one = tup.removeFrom1();

        //get
        //System.out.println("The second tuple: "+ tup.getValue(1));
        //System.out.println("The second tuple: "+ tup.getValue1());
        System.out.println("Tuple values: ");
        //traverse
        for(Object p : one){
            System.out.println(p);
        }
        //traverse
       /* System.out.println("Updated tuple: ");
        Iterator pr = newTup.iterator();
        while(pr.hasNext()){
            System.out.println(pr.next());
        }*/
    }
}
