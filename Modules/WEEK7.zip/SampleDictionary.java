import java.util.Dictionary;
import java.util.Enumeration;
import java.util.Hashtable;

public class SampleDictionary {
    public static void main(String[] args) {
        Dictionary <Integer, String> ds = new Hashtable<>();
        //add values
        ds.put(1, "Hollie");
        ds.put(2, "Angel");
        ds.put(3, "Angeles");
        System.out.println(ds);
        //get value
        System.out.println(ds.get(3));
        //remove
        ds.remove(1);
        System.out.println(ds.get(1));

        //traverse
        Enumeration <Integer> key = ds.keys(); //keys
        Enumeration <String> value = ds.elements(); //values
        while(key.hasMoreElements()){
            System.out.println("Key: " + key.nextElement() + " " + value.nextElement());
        }

    }

}
