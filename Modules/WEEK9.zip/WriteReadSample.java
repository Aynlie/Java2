
import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class WriteReadSample {
    public static void main(String[] args) {
        try {
            Scanner in = new Scanner(System.in);
            String temp;
            String fileLocation = "C:\\Users\\Nickaela\\Documents\\StudentRecords.csv";
            FileWriter writer = new FileWriter(fileLocation); 
            Scanner reader = new Scanner(new File(fileLocation));
            for(int i = 0; i < 4; i++){
                System.out.print("Enter a name: ");
                temp = in.nextLine();
                writer.append(temp); //write
                //writer.append(","); //separator
                writer.append("\n");
            }
            writer.flush();
            writer.close();
            System.out.println("Records have been written to the file!");
            //read
            reader.useDelimiter("[\n]");
            while (reader.hasNext()) {
                System.out.println(reader.next());  
            }
            reader.close();
            in.close();
        } catch (Exception e) {
            System.out.println("Error!");
        }
        finally{
            System.out.println("Read complete!");
        }
    }

}
