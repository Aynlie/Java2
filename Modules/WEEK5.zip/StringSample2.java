/*
 * Create an application that will get a string from the user, then print all the numbers/digits inputted. 
 */
import java.util.Scanner;
public class StringSample2{
    public static void main(String []a){
        Scanner key = new Scanner(System.in);
        String word;
        int cnt = 0;
        System.out.print("Enter a string: ");
        word = key.nextLine();
        System.out.println("The total length of " + word + " is " + word.length());
        System.out.print("The digits/: ");
        for(int index = 0; index < word.length(); index++){
            char c = word.charAt(index);
            if(Character.isDigit(c)){
                System.out.print(c + " ");
                cnt++;
            } 
        }
        if(cnt == 0){
            System.out.println("None");
        }
    }
}