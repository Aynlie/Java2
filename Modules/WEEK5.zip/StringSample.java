/*Create an application that will get a name from the user and check if the first letter is upper case, then
 * greet the name "Welcome!", otherwise, greet "Mabuhay!".
 */
import java.util.Scanner;
public class StringSample {
    public static void main(String []args){
        Scanner input = new Scanner(System.in);
        String na;
        char firstChar;
        //String na = new String("");
        //String na = "";
        
        System.out.println("Enter a name: ");
        na = input.nextLine();
        firstChar = na.charAt(0);
        if(Character.isUpperCase(firstChar)){
            System.out.println("Welcome! " + na);
        }
        else{
            System.out.println("Mabuhay! " + na);
        }
        


    }
}
