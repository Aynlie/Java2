//List is an ordered collection and allows duplication.
//Create a list with names of your friends.
import java.util.*;
public class ListSample {
    public static void main(String[] args) {
        List <String> friends = new ArrayList <String>();
        friends.add("Felix");
        friends.add("Foxie");
        friends.add("Orange");
        friends.add("Foxie");
        //System.out.println(friends);
        //System.out.println(friends.get(2)); //access
        friends.set(1, "Java"); //update
        friends.add(2, "HAU"); //insert in between
       //friends.remove(4);
        friends.clear();
        System.out.println();
        Iterator <String> fr = friends.iterator();
        while(fr.hasNext()){
            String name = fr.next();
            System.out.println("Friend: " + name);
        }
    }
}
