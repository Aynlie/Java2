//Set is unordered collection and no duplication.
import java.util.*;
public class SetSample {
    public static void main(String[] args) {
        Set <Integer> num = new HashSet <Integer> ();
        //TreeSet if you want it to be in order.
        num.add(10);
        num.add(45);
        num.add(2);
        num.add(4);
        num.add(45);
        num.addAll(Arrays.asList( new Integer[] { 1, 3, 2, 4, 8, 9, 0 }));
        System.out.println(num);
    }
}
