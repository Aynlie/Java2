import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.TreeSet;
import java.util.Scanner;
public class SetOperations {
    public static void main(String[] args) {
        Set<Integer> numbers = new TreeSet<Integer>();
        Set<Integer> num = new TreeSet<Integer>();
        numbers.addAll(Arrays.asList(new Integer[] { 1, 3, 2, 4, 8, 9, 0}));
        numbers.add(100);
        num.addAll(Arrays.asList(new Integer[] { 100, 6, 2, 4, 8, 5, 7}));
        Set<Integer> union = new TreeSet<Integer>(numbers);
        union.addAll(num);
        System.out.print("Union of the two Set");
        System.out.println(union);
        //System.out.println(numbers);
        Set<Integer> intersection = new TreeSet<Integer>(numbers);
        intersection.retainAll(num);
        System.out.print("Intersection of the two Set");
        System.out.println(intersection);
        Set<Integer> difference = new TreeSet<Integer>(numbers);
        difference.removeAll(num);
        System.out.print("Difference of the two Set");
        System.out.println(difference); 
    }
}
