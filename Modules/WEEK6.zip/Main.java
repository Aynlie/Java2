import java.util.*;
public class Main {
    public static void main(String args[]) {
        Scanner in = new Scanner(System.in);
        List<String> names = new ArrayList<String>();
        names.add("HAU");
        names.add("SOC");
        names.add("ICT 111");
        names.add("Java");
        Iterator<String> iterate = names.iterator();
        
        //Iterator using while loop
        while(iterate.hasNext()){
            String element = iterate.next();
            System.out.println("Hello! " + element);
        }
        
        //Iterator using for loop
        for(;iterate.hasNext();){
            String element = iterate.next();
            System.out.println("Hello! " + element);
        }
        
        //Using enhanced for loop
        for(String n: names){
            System.out.println("Hello! " + n);
        }
        /*
        //Using do while loop, but make sure the list/set is not empty
        do{
            String element = iterate.next();
            System.out.println("Hello! " + element);
        }while(iterate.hasNext());
        */
        in.close();
    }
}