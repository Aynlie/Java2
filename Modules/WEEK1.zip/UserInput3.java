import javax.swing.*;
public class UserInput3 {
	public static void main(String [] args) {	
		double num1 = 0;
		double num2 = 0;
		double sum = 0;
		String temp;
		temp = JOptionPane.showInputDialog(null, "Enter a number: ");
		num1 = Double.parseDouble(temp);
		temp = JOptionPane.showInputDialog(null, "Enter a number: ");
		num2 = Double.parseDouble(temp);
		sum = num1 + num2;
		JOptionPane.showMessageDialog(null, "The sum of numbers  " + num1 + " and " + num2 + " is " + sum + ".");
	}
}