//Create an application that will compute for the change of the user in a simple POS.
import java.util.*;
public class InputFilter{
	public static void main(String [] args){
		Scanner key = new Scanner(System.in);
		char item;
		double price = 0;
		int quantity = 0;
		double money = 0;
		double change = 0;
		double total = 0;
		System.out.println("[1] Ballpen\n[2] Pencil\n[3] Paper");
		System.out.print("Enter the item code: ");
		//.chatAt() to assign a character to a variable depending on the index
		item = key.nextLine().charAt(0);
		switch(item){
		case '1': price = 10; break;
		case '2': price = 7.5; break;
		case '3': price = 25; break;
		default: price = 0; break;
		}

		/*
		if(item == '1')
			price = 10;
		else if(item == '2')
			price = 7.5;
		else if(item == '3')
			price = 25;
		else
			price = 0;
		*/

		if(price != 0){
			System.out.print("Enter the quantity of the item: ");
			quantity = key.nextInt();
			System.out.print("Enter the amount of your money: P ");
			money = key.nextDouble();
			total = price * quantity;
			if(total <= money){
				change = money - total;
			System.out.print("The change is P " + String.format("%.2f", change));	
			}else{
				System.out.print("The amount of money is insufficient.");
			}
		}else{
			System.out.println("Wrong item code.");
		}
	}
}