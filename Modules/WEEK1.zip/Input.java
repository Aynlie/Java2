//Create an application that will compute for the change of the user in a simple POS.
import java.util.*;
public class Input{
	public static void main(String [] args){
		Scanner key = new Scanner(System.in);
		double item = 0;
		int quantity = 0;
		double money = 0;
		double change = 0;
		double total = 0;

		System.out.print("Enter the price of the item: P ");
		item = key.nextDouble();
		System.out.print("Enter the quantity of the item: ");
		quantity = key.nextInt();
		System.out.print("Enter the amount of your money: P ");
		money = key.nextDouble();
		total = item * quantity;
		change = money - total;
		System.out.print("The change is P " + String.format("%.2f", change));

	}
}