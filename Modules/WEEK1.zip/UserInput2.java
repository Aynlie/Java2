import java.io.*;
public class UserInput2 {
	public static void main(String [] args) throws Exception{	
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		double num1 = 0;
		int num2 = 0;
		double sum = 0;
		String temp;
		System.out.print("Enter a number: ");
		temp = in.readLine();
		//parsing
		num1 = Double.parseDouble(temp);
		System.out.print("Enter a number: ");
		num2 = Integer.parseInt(in.readLine());
		sum = num1 + num2;
		System.out.println("The sum of numbers  " + num1 + " and " + num2 + " is " + sum + ".");
	}
}