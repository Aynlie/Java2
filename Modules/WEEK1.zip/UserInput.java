import java.util.Scanner;
public class UserInput {
	public static void main(String [] args){	
		Scanner input = new Scanner(System.in);
		double num1 = 0;
		double num2 = 0;
		//double sum;
		int sum;
		System.out.print("Enter a number: ");
		num1 = input.nextDouble();
		System.out.print("Enter a number: ");
		num2 = input.nextDouble();
		//sum = num1 + num2;
		//typecasting
		sum = (int)(num1 + num2);
		System.out.println("The sum of numbers  " + num1 + " and " + num2 + " is " + sum + ".");
	}
}