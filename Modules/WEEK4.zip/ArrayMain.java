//Highest and longest

import java.util.Scanner;

public class ArrayMain {
    public static void main(String[] args) {
        Scanner in = new Scanner(System.in);
        int num [] = {10, 200, 4500, 400, 55};
        String n [] = new String [5];
        int cnt = 0;
        int highest = 0;
        for(int idx = 0; idx < num.length; idx++){
        //for(int idx = (num.length - 1); idx >= 0; idx--){
            System.out.println(num[idx]);
            if(idx == 0){
                highest = num[0];
            }else{
                if(highest < num[idx]){
                    highest = num[idx];
                }
            }
        }
        System.out.println("The highest number in the array is " + highest);
        do{
            System.out.print("Enter a name: ");
            n[cnt] = in.nextLine();
            cnt++;
        }while(cnt < n.length);
        printName(n);
        nameLongest(n);
    }
    public static void printName(String names[]){
        int index = 0;
        for(String n: names){
            System.out.println("["+ index + "] " + n);
            index++;
        }
    }
    public static void nameLongest(String names[]){
        int longest = 0;
        int cnt = 0;
        for(String name: names)
        if(name.length() > longest){
            longest = name.length();
        }

        while(cnt < names.length){
            if(names[cnt].length() == longest){
                System.out.println("Longest name: " + names[cnt]);
            }
            cnt++;
        }
    }
}
