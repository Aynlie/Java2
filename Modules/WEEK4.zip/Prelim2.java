/*Create an application that asks the user to input two integers in the main method and pass the two integers to a method named computeSum to display the sum from the lower integer up to the higher integer. Make sure to track which is the lower and higher integer regardless of the order of inputs and provide notification for equal inputs. 
*/
import java.util.Scanner;
public class Prelim2 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int high = 0;
		int low = 0; 
		//input numbers
        System.out.print("Enter first integer: ");
        int first = input.nextInt();     
        System.out.print("Enter second integer: ");
        int second = input.nextInt();
		//to filter the high and low inputs
        if(first > second){
            high = first;
            low = second;    
        }
        else{
            high = second;
            low = first;
        }
        if(high != low)
            sum(high, low);
        else //for filtering of equal values
            System.out.println("Please enter not the same values.");
    }
    public static void sum(int high, int low){
        int sum = 0;
		//loop to get the sum of the numbers from low to high
        for(int ctr = low; ctr <= high; ctr++){
            sum+= ctr;
        }
		//print the sum
        System.out.println("The sum from "+ low + " to " + high + " : " + sum);
    }
}